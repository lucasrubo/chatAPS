# Socket-chat
Clone project and jun host alongside with server,
Copy and paste your desktop name into the server file and hit enter,
Enjoy Chatting :)
